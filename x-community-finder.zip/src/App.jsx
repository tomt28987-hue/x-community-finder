import { useState, useEffect, useCallback } from 'react'

// ── Storage ──────────────────────────────────────────────────────────────────
const CFG_KEY  = 'cx_config'
const SAVE_KEY = 'cx_saved'
const load = (k, fb={}) => { try { return JSON.parse(localStorage.getItem(k)||'null') ?? fb } catch { return fb } }
const save = (k,v) => localStorage.setItem(k, JSON.stringify(v))

// ── X API ────────────────────────────────────────────────────────────────────
const XAPI = {
  async search(bearer, query, max=20) {
    const p = new URLSearchParams({
      query,
      max_results: String(Math.min(Math.max(Number(max),1),20)),
      'user.fields': 'description,public_metrics,profile_image_url,created_at,url'
    })
    const r = await fetch(`https://api.twitter.com/2/users/search?${p}`, {
      headers: { Authorization: `Bearer ${bearer}` }
    })
    if (!r.ok) {
      const t = await r.text()
      throw new Error(`X API ${r.status}: ${t.slice(0,220)}`)
    }
    return r.json()
  },
  async getMe(tok) {
    const r = await fetch('https://api.twitter.com/2/users/me', {
      headers: { Authorization: `Bearer ${tok}` }
    })
    if (!r.ok) throw new Error(`X API ${r.status}`)
    return (await r.json()).data
  },
  async follow(tok, myId, targetId) {
    const r = await fetch(`https://api.twitter.com/2/users/${myId}/following`, {
      method:'POST',
      headers:{ Authorization:`Bearer ${tok}`, 'Content-Type':'application/json' },
      body: JSON.stringify({ target_user_id: targetId })
    })
    if (!r.ok) throw new Error(`Follow ${r.status}: ${(await r.text()).slice(0,150)}`)
    return r.json()
  }
}

// ── AI Scoring ────────────────────────────────────────────────────────────────
async function scoreForCommunity(accounts, criteria) {
  const prompt = `You help someone build a genuine, small community on X (Twitter) — think real everyday people, not influencers or brands.

The user wants to connect with: "${criteria}"

For each account below, evaluate how well they fit as a genuine community member — someone real, relatable, and likely to engage back. 
Reward: authentic bios, personal content, regular people with small followings.
Penalize: obvious bots, brands, accounts with no bio, zero tweets, or suspiciously high following-to-follower ratios.

Accounts:
${accounts.map((a,i) => `${i+1}. @${a.username} — "${a.name}"
   Bio: ${a.description||'(none)'}
   Followers: ${a.public_metrics?.followers_count??'?'} | Following: ${a.public_metrics?.following_count??'?'} | Tweets: ${a.public_metrics?.tweet_count??'?'}`).join('\n\n')}

Return ONLY a valid JSON array, no markdown:
[{
  "username":"handle",
  "communityScore":0-100,
  "authenticityScore":0-100,
  "matchSummary":"1-2 sentences on why this person fits the community goal",
  "communityRole":"The Connector"|"The Regular"|"The Contributor"|"The Quiet One"|"Low Fit",
  "tags":["tag1","tag2"],
  "redFlags":["flag if any, else empty array"]
}]`

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method:'POST',
    headers:{ 'Content-Type':'application/json' },
    body: JSON.stringify({
      model:'claude-sonnet-4-20250514',
      max_tokens:1200,
      messages:[{ role:'user', content:prompt }]
    })
  })
  const data = await res.json()
  const text = data.content?.map(b=>b.text||'').join('') || ''
  return JSON.parse(text.replace(/```json|```/g,'').trim())
}

// ── Helpers ───────────────────────────────────────────────────────────────────
const fmt = n => {
  if (!n && n!==0) return '—'
  if (n>=1e6) return (n/1e6).toFixed(1)+'M'
  if (n>=1e3) return (n/1e3).toFixed(1)+'K'
  return String(n)
}
const roleColor = r => ({
  'The Connector':'#f472b6',
  'The Regular':'#60a5fa',
  'The Contributor':'#4ade80',
  'The Quiet One':'#fbbf24',
  'Low Fit':'#6b7280'
}[r]||'#6b7280')

const roleIcon = r => ({
  'The Connector':'🤝','The Regular':'👤','The Contributor':'✍️','The Quiet One':'👁','Low Fit':'·'
}[r]||'·')

// ── Global CSS ────────────────────────────────────────────────────────────────
const G = `
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=DM+Mono:wght@400;500&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#0d0d0d; --s1:#141414; --s2:#1a1a1a; --bd:#252525;
  --acc:#e8ff47; --acc2:#ff6b35; --blue:#60a5fa; --green:#4ade80;
  --red:#f87171; --pink:#f472b6; --yellow:#fbbf24;
  --tx:#f0f0f0; --mu:#5a5a5a; --r:14px;
  --st:env(safe-area-inset-top,0px);
  --sb:env(safe-area-inset-bottom,0px);
}
html,body,#root{height:100%;width:100%;overflow:hidden}
body{background:var(--bg);color:var(--tx);font-family:'Outfit',sans-serif;-webkit-font-smoothing:antialiased}
input,textarea,select,button{font-family:'Outfit',sans-serif}
::-webkit-scrollbar{width:3px}
::-webkit-scrollbar-thumb{background:var(--bd);border-radius:2px}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes up{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.5}}
`

// ═══════════════════════════════════════════════════════════════════════════════
// SCREEN: SETUP
// ═══════════════════════════════════════════════════════════════════════════════
function SetupScreen({ onSave }) {
  const cfg = load(CFG_KEY)
  const [bearer, setBearer] = useState(cfg.bearer||'')
  const [userTok, setUserTok] = useState(cfg.userTok||'')
  const [step, setStep] = useState(0)

  const steps = [
    {
      icon:'🔑', title:'Your Bearer Token',
      content:(
        <div style={sx.col}>
          <p style={sx.hint}>This lets the app search real X accounts. Free, takes 2 min.</p>
          <div style={sx.steps}>
            {['Go to developer.x.com → sign in with your X account',
              'Create a New Project + App (any name works)',
              'Open Keys and Tokens → copy your Bearer Token'
            ].map((t,i)=>(
              <div key={i} style={sx.stepRow}>
                <div style={sx.stepNum}>{i+1}</div>
                <div style={sx.stepTxt}>{t}</div>
              </div>
            ))}
          </div>
          <a href="https://developer.x.com/en/portal/dashboard" target="_blank" rel="noreferrer" style={sx.link}>
            Open X Developer Portal →
          </a>
          <label style={sx.lbl}>Paste Bearer Token</label>
          <input style={sx.inp} type="password" placeholder="AAAA…" value={bearer} onChange={e=>setBearer(e.target.value)}/>
        </div>
      ),
      ok: bearer.length > 20
    },
    {
      icon:'✍️', title:'Follow Token (optional)',
      content:(
        <div style={sx.col}>
          <p style={sx.hint}>Only needed to follow from inside the app. You can always follow manually on X instead.</p>
          <div style={sx.steps}>
            {['In your X App → User Authentication Settings',
              'Enable OAuth 2.0 → set to Read + Write',
              'Add your deployed URL as the callback URL',
              'Use the PKCE flow to get a User Access Token'
            ].map((t,i)=>(
              <div key={i} style={sx.stepRow}>
                <div style={sx.stepNum}>{i+1}</div>
                <div style={sx.stepTxt}>{t}</div>
              </div>
            ))}
          </div>
          <label style={sx.lbl}>User Access Token (leave blank to skip)</label>
          <input style={sx.inp} type="password" placeholder="Optional…" value={userTok} onChange={e=>setUserTok(e.target.value)}/>
        </div>
      ),
      ok: true
    },
    {
      icon:'📱', title:'Install on your devices',
      content:(
        <div style={sx.col}>
          <p style={sx.hint}>After deploying to Vercel, add the app to every device like a native app.</p>
          {[
            {d:'iPhone / iPad', i:'🍎', s:'Safari → Share button → "Add to Home Screen"'},
            {d:'Android', i:'🤖', s:'Chrome → ⋮ menu → "Install App" or "Add to Home Screen"'},
            {d:'Mac / Windows', i:'💻', s:'Chrome → install icon in address bar → "Install"'}
          ].map(({d,i,s})=>(
            <div key={d} style={sx.deviceCard}>
              <div style={{fontSize:20}}>{i}</div>
              <div>
                <div style={{fontWeight:700,fontSize:14,marginBottom:3}}>{d}</div>
                <div style={{fontSize:12,color:'var(--mu)',lineHeight:1.55}}>{s}</div>
              </div>
            </div>
          ))}
        </div>
      ),
      ok: true
    }
  ]

  const cur = steps[step]
  return (
    <div style={sx.setupWrap}>
      <div style={sx.setupTop}>
        <div style={sx.logo}>𝕏</div>
        <div>
          <div style={{fontWeight:800,fontSize:19,letterSpacing:'-0.3px'}}>Community Finder</div>
          <div style={{fontSize:12,color:'var(--mu)',fontFamily:'DM Mono'}}>Setup · Step {step+1} of {steps.length}</div>
        </div>
      </div>

      <div style={sx.progressBar}>
        <div style={{...sx.progressFill, width:`${((step+1)/steps.length)*100}%`}}/>
      </div>

      <div style={sx.setupCard}>
        <div style={sx.setupIcon}>{cur.icon}</div>
        <div style={{fontWeight:800,fontSize:21,marginBottom:18,letterSpacing:'-0.3px'}}>{cur.title}</div>
        {cur.content}
      </div>

      <div style={sx.setupNav}>
        {step>0 && <button style={{...sx.btn,...sx.btnGhost}} onClick={()=>setStep(p=>p-1)}>← Back</button>}
        {step<steps.length-1
          ? <button style={{...sx.btn,...sx.btnAcc,marginLeft:'auto',opacity:cur.ok?1:0.35}} onClick={()=>cur.ok&&setStep(p=>p+1)}>Next →</button>
          : <button style={{...sx.btn,...sx.btnAcc,marginLeft:'auto'}} onClick={()=>{save(CFG_KEY,{bearer,userTok});onSave({bearer,userTok})}}>Let's Find People ✓</button>
        }
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// SCREEN: SEARCH
// ═══════════════════════════════════════════════════════════════════════════════
function SearchScreen({ config, onResults, onSaved, savedCount, onSettings }) {
  const [query, setQuery]       = useState('')
  const [minF, setMinF]         = useState(1)
  const [maxF, setMaxF]         = useState(1000)
  const [loading, setLoading]   = useState(false)
  const [loadMsg, setLoadMsg]   = useState('')
  const [error, setError]       = useState('')

  const templates = [
    { label:'🏈 Sports fans', q:'regular guy who loves sports, NFL, football, watching games with family' },
    { label:'⛪ Faith & family', q:'Christian man faith family values daily life' },
    { label:'🏕️ Outdoors', q:'man who hunts fishes camping outdoors nature' },
    { label:'💪 Fitness', q:'regular guy working out gym fitness health journey' },
    { label:'🛠️ Builders', q:'guy who builds things DIY woodworking fixing cars' },
    { label:'📖 Everyday life', q:'regular person sharing daily life thoughts real conversations' },
  ]

  const run = useCallback(async () => {
    if (!query.trim()) return
    setError(''); setLoading(true)
    try {
      setLoadMsg('Searching X for real people…')
      const data = await XAPI.search(config.bearer, query, 20)
      const users = (data.data||[])

      // Client-side follower filter
      const filtered = users.filter(u => {
        const fc = u.public_metrics?.followers_count ?? 0
        return fc >= minF && fc <= maxF
      })

      if (!filtered.length) {
        throw new Error(`No accounts found in the ${minF}–${fmt(maxF)} follower range. Try broader keywords or widen the range.`)
      }

      setLoadMsg('Evaluating community fit with AI…')
      const scored = await scoreForCommunity(filtered, query)

      const merged = scored
        .map(s => ({ ...(filtered.find(u=>u.username===s.username)||{}), ...s }))
        .filter(a=>a.username)
        .sort((a,b)=>(b.communityScore||0)-(a.communityScore||0))

      onResults(merged, query, {minF, maxF})
    } catch(e) {
      setError(e.message)
    } finally {
      setLoading(false); setLoadMsg('')
    }
  }, [query, minF, maxF, config.bearer, onResults])

  return (
    <div style={sx.screen}>
      {/* Header */}
      <div style={sx.hdr}>
        <div style={sx.logo}>𝕏</div>
        <div style={{flex:1}}>
          <div style={{fontWeight:800,fontSize:17}}>Community Finder</div>
          <div style={{fontSize:11,color:'var(--mu)'}}>Real people · Small followings</div>
        </div>
        {savedCount>0 && (
          <button style={sx.savedPill} onClick={onSaved}>
            ⭐ {savedCount}
          </button>
        )}
        <button style={sx.iconBtn} onClick={onSettings}>⚙️</button>
      </div>

      <div style={sx.body}>
        {/* Hero */}
        <div style={sx.hero}>
          <span style={sx.heroAccent}>Find your people.</span>
          <br/>Real accounts, small followings,<br/>genuine connections.
        </div>

        {/* Templates */}
        <div>
          <div style={sx.sectionLabel}>Quick searches</div>
          <div style={sx.chips}>
            {templates.map(t=>(
              <button key={t.label} style={{...sx.chip, ...(query===t.q?sx.chipActive:{})}} onClick={()=>setQuery(t.q)}>
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Query */}
        <div>
          <div style={sx.sectionLabel}>Describe who you're looking for</div>
          <textarea
            style={sx.bigInput}
            rows={3}
            placeholder="e.g. regular guy who loves football, family, and shares everyday life…"
            value={query}
            onChange={e=>setQuery(e.target.value)}
          />
        </div>

        {/* Follower range */}
        <div>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:10}}>
            <div style={sx.sectionLabel}>Follower range</div>
            <div style={sx.rangeBadge}>{fmt(minF)} – {fmt(maxF)}</div>
          </div>
          <div style={sx.rangeRow}>
            <div style={sx.rangeGroup}>
              <label style={sx.rangeLabel}>Min</label>
              <select style={sx.sel} value={minF} onChange={e=>setMinF(Number(e.target.value))}>
                {[0,1,10,50,100,200,500].map(n=><option key={n} value={n}>{n===0?'Any':n}</option>)}
              </select>
            </div>
            <div style={{color:'var(--mu)',fontSize:18,paddingTop:16}}>→</div>
            <div style={sx.rangeGroup}>
              <label style={sx.rangeLabel}>Max</label>
              <select style={sx.sel} value={maxF} onChange={e=>setMaxF(Number(e.target.value))}>
                {[100,250,500,1000,2500,5000,999999].map(n=><option key={n} value={n}>{n===999999?'Any':fmt(n)}</option>)}
              </select>
            </div>
          </div>
          <div style={sx.rangeNote}>
            Targeting <strong style={{color:'var(--acc)'}}>1–1,000</strong> by default to find real community members, not influencers
          </div>
        </div>

        {error && <div style={sx.errBox}>{error}</div>}

        <button
          style={{...sx.btn,...sx.btnAcc,...sx.btnFull, opacity:(!query.trim()||loading)?0.35:1}}
          onClick={run}
          disabled={loading||!query.trim()}
        >
          {loading
            ? <><span style={sx.spin}/>{loadMsg}</>
            : '🔍 Find Community Members'
          }
        </button>

        <div style={sx.safeNote}>
          ✓ No auto-follow &nbsp;·&nbsp; ✓ Manual approval only &nbsp;·&nbsp; ✓ X-compliant
        </div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// SCREEN: RESULTS
// ═══════════════════════════════════════════════════════════════════════════════
function ResultsScreen({ results, query, filters, config, onBack, onSaveToggle, savedIds }) {
  const [cardState, setCardState] = useState({})
  const [myId, setMyId]           = useState(null)
  const [err, setErr]             = useState('')
  const [tab, setTab]             = useState('all') // all | strong | saved

  const cs  = u => cardState[u]||'idle'
  const setCs = (u,v) => setCardState(p=>({...p,[u]:v}))

  const follow = async (acct) => {
    if (!config.userTok) { setErr('No User Token configured. Go to Settings to add it.'); return }
    setCs(acct.username,'following')
    try {
      let id = myId
      if (!id) { const me = await XAPI.getMe(config.userTok); id=me.id; setMyId(id) }
      await XAPI.follow(config.userTok, id, acct.id)
      setCs(acct.username,'followed')
    } catch(e) {
      setCs(acct.username,'err')
      setErr(`@${acct.username}: ${e.message}`)
    }
  }

  const shown = results.filter(a => {
    if (tab==='strong') return (a.communityScore||0) >= 70
    if (tab==='saved')  return savedIds.has(a.username)
    return true
  })

  return (
    <div style={sx.screen}>
      {/* Header */}
      <div style={sx.hdr}>
        <button style={sx.backBtn} onClick={onBack}>←</button>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontWeight:800,fontSize:16}}>Community Members</div>
          <div style={{fontSize:11,color:'var(--mu)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
            {filters.minF}–{fmt(filters.maxF)} followers · {results.length} found
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={sx.tabs}>
        {[['all','All'],['strong','Best Fit'],['saved','Saved ⭐']].map(([v,l])=>(
          <button key={v} style={{...sx.tab,...(tab===v?sx.tabActive:{})}} onClick={()=>setTab(v)}>
            {l}{v==='all'?` (${results.length})`:v==='strong'?` (${results.filter(a=>(a.communityScore||0)>=70).length})`:` (${savedIds.size})`}
          </button>
        ))}
      </div>

      {err && (
        <div style={{...sx.errBox,margin:'0 16px 8px',flexDirection:'row',justifyContent:'space-between'}}>
          <span>{err}</span>
          <button style={{background:'none',border:'none',color:'var(--mu)',cursor:'pointer',fontSize:14}} onClick={()=>setErr('')}>✕</button>
        </div>
      )}

      {/* Cards */}
      <div style={sx.cardsList}>
        {shown.length===0 && (
          <div style={sx.empty}>
            <div style={{fontSize:40,marginBottom:12}}>🔍</div>
            <div style={{fontWeight:700,fontSize:16,marginBottom:6}}>
              {tab==='saved'?'No saved members yet':'No results here'}
            </div>
            <div style={{fontSize:13,color:'var(--mu)'}}>
              {tab==='saved'?'Tap ⭐ on any card to save them':'Try the All tab'}
            </div>
          </div>
        )}
        {shown.map((a, idx) => {
          const state   = cs(a.username)
          const score   = a.communityScore||0
          const auth    = a.authenticityScore||0
          const rColor  = roleColor(a.communityRole)
          const initial = (a.name||a.username||'?')[0].toUpperCase()
          const isSaved = savedIds.has(a.username)

          return (
            <div key={a.username} style={{...sx.card, animationDelay:`${idx*50}ms`}}>
              {/* Top */}
              <div style={sx.cardTop}>
                <div style={{position:'relative'}}>
                  {a.profile_image_url
                    ? <img src={a.profile_image_url.replace('_normal','_bigger')} style={sx.ava} alt=""/>
                    : <div style={sx.avaPh}>{initial}</div>
                  }
                  <div style={{...sx.roleIcon, background:rColor+'22', color:rColor}}>
                    {roleIcon(a.communityRole)}
                  </div>
                </div>

                <div style={{flex:1,minWidth:0}}>
                  <div style={{display:'flex',alignItems:'center',gap:7,flexWrap:'wrap'}}>
                    <span style={sx.cardName}>{a.name}</span>
                    {a.communityRole && a.communityRole!=='Low Fit' && (
                      <span style={{...sx.roleBadge, color:rColor, borderColor:rColor+'44', background:rColor+'11'}}>
                        {a.communityRole}
                      </span>
                    )}
                  </div>
                  <div style={sx.handle}>@{a.username}</div>
                </div>

                {/* Save button */}
                <button style={{...sx.starBtn, color:isSaved?'var(--yellow)':'var(--mu)'}} onClick={()=>onSaveToggle(a)}>
                  {isSaved?'★':'☆'}
                </button>
              </div>

              {/* Scores */}
              <div style={sx.scoreRow}>
                <div style={sx.scoreBlock}>
                  <div style={{...sx.scoreBar}}>
                    <div style={{...sx.scoreFill, width:`${score}%`, background:`linear-gradient(90deg, var(--acc), var(--acc2))`}}/>
                  </div>
                  <div style={sx.scoreLabels}>
                    <span style={{fontSize:11,color:'var(--mu)'}}>Community fit</span>
                    <span style={{fontSize:12,fontWeight:700,fontFamily:'DM Mono',color:'var(--acc)'}}>{score}</span>
                  </div>
                </div>
                <div style={sx.scoreBlock}>
                  <div style={sx.scoreBar}>
                    <div style={{...sx.scoreFill, width:`${auth}%`, background:`linear-gradient(90deg,var(--green),var(--blue))`}}/>
                  </div>
                  <div style={sx.scoreLabels}>
                    <span style={{fontSize:11,color:'var(--mu)'}}>Authenticity</span>
                    <span style={{fontSize:12,fontWeight:700,fontFamily:'DM Mono',color:'var(--green)'}}>{auth}</span>
                  </div>
                </div>
              </div>

              {a.description && <div style={sx.bio}>{a.description}</div>}

              {a.matchSummary && (
                <div style={sx.matchBox}>💬 {a.matchSummary}</div>
              )}

              {a.redFlags?.length>0 && (
                <div style={sx.flagBox}>⚠️ {a.redFlags.join(' · ')}</div>
              )}

              {a.tags?.length>0 && (
                <div style={sx.tags}>{a.tags.map(t=><span key={t} style={sx.tag}>{t}</span>)}</div>
              )}

              <div style={sx.metrics}>
                <span style={sx.metric}><b style={{color:'var(--tx)'}}>{fmt(a.public_metrics?.followers_count)}</b> followers</span>
                <span style={sx.metric}><b style={{color:'var(--tx)'}}>{fmt(a.public_metrics?.following_count)}</b> following</span>
                <span style={sx.metric}><b style={{color:'var(--tx)'}}>{fmt(a.public_metrics?.tweet_count)}</b> tweets</span>
              </div>

              <div style={sx.actionRow}>
                {state==='idle'    && <button style={{...sx.followBtn,...sx.fApprove}} onClick={()=>setCs(a.username,'approved')}>＋ Approve to Follow</button>}
                {state==='approved'&& <button style={{...sx.followBtn,...sx.fConfirm}} onClick={()=>follow(a)}>✓ Confirm Follow @{a.username}</button>}
                {state==='following'&&<button style={{...sx.followBtn,...sx.fPending}} disabled><span style={sx.spin}/>Following…</button>}
                {state==='followed'&& <button style={{...sx.followBtn,...sx.fDone}} disabled>✓ Following</button>}
                {state==='err'     && <button style={{...sx.followBtn,...sx.fApprove}} onClick={()=>setCs(a.username,'approved')}>Retry</button>}
                <a href={`https://x.com/${a.username}`} target="_blank" rel="noreferrer" style={sx.viewLink}>View ↗</a>
              </div>
            </div>
          )
        })}
        <div style={sx.footer}>Manual follow only · No bulk actions · X automation compliant</div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// ROOT APP
// ═══════════════════════════════════════════════════════════════════════════════
export default function App() {
  const [screen,   setScreen]   = useState('boot')
  const [config,   setConfig]   = useState({})
  const [results,  setResults]  = useState([])
  const [query,    setQuery]    = useState('')
  const [filters,  setFilters]  = useState({minF:1,maxF:1000})
  const [saved,    setSaved]    = useState(() => load(SAVE_KEY, []))

  useEffect(() => {
    const cfg = load(CFG_KEY)
    if (cfg?.bearer?.length>20) { setConfig(cfg); setScreen('search') }
    else setScreen('setup')
  }, [])

  const savedIds = new Set(saved.map(a=>a.username))

  const toggleSave = (acct) => {
    setSaved(prev => {
      const next = savedIds.has(acct.username)
        ? prev.filter(a=>a.username!==acct.username)
        : [...prev, acct]
      save(SAVE_KEY, next)
      return next
    })
  }

  const handleResults = (r, q, f) => { setResults(r); setQuery(q); setFilters(f); setScreen('results') }

  if (screen==='boot') return (
    <div style={{background:'var(--bg)',height:'100vh',display:'flex',alignItems:'center',justifyContent:'center'}}>
      <span style={sx.spin}/>
    </div>
  )

  return (
    <>
      <style>{G}</style>
      {screen==='setup'   && <SetupScreen onSave={cfg=>{setConfig(cfg);setScreen('search')}}/>}
      {screen==='search'  && (
        <SearchScreen
          config={config}
          onResults={handleResults}
          onSaved={()=>setScreen('results')}
          savedCount={saved.length}
          onSettings={()=>setScreen('setup')}
        />
      )}
      {screen==='results' && (
        <ResultsScreen
          results={results}
          query={query}
          filters={filters}
          config={config}
          onBack={()=>setScreen('search')}
          onSaveToggle={toggleSave}
          savedIds={savedIds}
        />
      )}
    </>
  )
}

// ── Style objects ─────────────────────────────────────────────────────────────
const sx = {
  screen:{height:'100%',display:'flex',flexDirection:'column',maxWidth:500,margin:'0 auto',width:'100%'},
  body:{flex:1,overflowY:'auto',padding:'20px 16px',display:'flex',flexDirection:'column',gap:20},

  // Setup
  setupWrap:{height:'100%',display:'flex',flexDirection:'column',padding:'calc(var(--st) + 20px) 16px calc(var(--sb) + 20px)',gap:16,overflowY:'auto',maxWidth:500,margin:'0 auto',width:'100%'},
  setupTop:{display:'flex',alignItems:'center',gap:14,paddingBottom:4},
  logo:{width:42,height:42,background:'#000',border:'1.5px solid var(--bd)',borderRadius:11,display:'flex',alignItems:'center',justifyContent:'center',fontSize:20,fontWeight:900,flexShrink:0,color:'#fff'},
  progressBar:{height:3,background:'var(--bd)',borderRadius:2},
  progressFill:{height:'100%',background:'var(--acc)',borderRadius:2,transition:'width 0.4s ease'},
  setupCard:{background:'var(--s1)',border:'1px solid var(--bd)',borderRadius:18,padding:22,flex:1},
  setupIcon:{fontSize:30,marginBottom:10},
  col:{display:'flex',flexDirection:'column',gap:14},
  hint:{fontSize:13,color:'var(--mu)',lineHeight:1.65},
  steps:{display:'flex',flexDirection:'column',gap:10},
  stepRow:{display:'flex',gap:12,alignItems:'flex-start'},
  stepNum:{width:22,height:22,borderRadius:'50%',background:'var(--acc)',color:'#000',fontWeight:800,fontSize:11,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,marginTop:1},
  stepTxt:{fontSize:13,color:'#c0c0c0',lineHeight:1.55},
  link:{color:'var(--acc)',fontSize:13,textDecoration:'none',fontWeight:600},
  lbl:{fontSize:11,color:'var(--mu)',fontFamily:'DM Mono',letterSpacing:1},
  inp:{background:'var(--s2)',border:'1px solid var(--bd)',color:'var(--tx)',padding:'10px 13px',borderRadius:10,fontSize:13,outline:'none',width:'100%',fontFamily:'DM Mono'},
  deviceCard:{display:'flex',gap:14,alignItems:'flex-start',background:'var(--s2)',border:'1px solid var(--bd)',borderRadius:10,padding:'12px 14px'},
  setupNav:{display:'flex',gap:10,paddingTop:4},
  btn:{padding:'13px 20px',borderRadius:12,fontWeight:700,fontSize:14,cursor:'pointer',border:'none',display:'flex',alignItems:'center',justifyContent:'center',gap:8,transition:'all 0.18s',letterSpacing:'0.2px'},
  btnAcc:{background:'var(--acc)',color:'#000'},
  btnGhost:{background:'var(--s2)',color:'var(--tx)',border:'1px solid var(--bd)'},
  btnFull:{width:'100%'},

  // Search
  hdr:{display:'flex',alignItems:'center',gap:12,padding:'calc(var(--st) + 14px) 16px 14px',borderBottom:'1px solid var(--bd)',flexShrink:0},
  hero:{fontSize:24,fontWeight:800,lineHeight:1.3,letterSpacing:'-0.5px'},
  heroAccent:{color:'var(--acc)'},
  sectionLabel:{fontSize:11,color:'var(--mu)',fontFamily:'DM Mono',letterSpacing:1.5,textTransform:'uppercase',marginBottom:10},
  chips:{display:'flex',flexWrap:'wrap',gap:8},
  chip:{background:'var(--s2)',border:'1px solid var(--bd)',color:'var(--mu)',padding:'7px 13px',borderRadius:999,fontSize:12,cursor:'pointer',fontWeight:500,transition:'all 0.15s'},
  chipActive:{background:'var(--acc)22',borderColor:'var(--acc)',color:'var(--acc)'},
  bigInput:{background:'var(--s1)',border:'1px solid var(--bd)',color:'var(--tx)',padding:'13px 14px',borderRadius:12,fontSize:14,outline:'none',width:'100%',resize:'none',lineHeight:1.6},
  rangeRow:{display:'flex',alignItems:'flex-end',gap:12},
  rangeGroup:{display:'flex',flexDirection:'column',gap:6,flex:1},
  rangeLabel:{fontSize:11,color:'var(--mu)',fontFamily:'DM Mono'},
  sel:{background:'var(--s2)',border:'1px solid var(--bd)',color:'var(--tx)',padding:'9px 12px',borderRadius:10,fontSize:13,outline:'none',width:'100%'},
  rangeBadge:{fontFamily:'DM Mono',fontSize:12,color:'var(--acc)',background:'var(--acc)11',border:'1px solid var(--acc)33',padding:'3px 10px',borderRadius:999},
  rangeNote:{fontSize:12,color:'var(--mu)',lineHeight:1.5},
  errBox:{background:'rgba(248,113,113,0.08)',border:'1px solid rgba(248,113,113,0.25)',color:'#fca5a5',borderRadius:10,padding:'11px 14px',fontSize:13,lineHeight:1.5,display:'flex',flexDirection:'column',gap:4},
  safeNote:{textAlign:'center',fontSize:11,color:'var(--mu)',fontFamily:'DM Mono'},
  savedPill:{background:'var(--yellow)18',border:'1px solid var(--yellow)44',color:'var(--yellow)',padding:'5px 12px',borderRadius:999,fontSize:12,fontWeight:700,cursor:'pointer'},
  iconBtn:{background:'none',border:'none',cursor:'pointer',fontSize:20,padding:4,color:'var(--mu)'},

  // Results
  tabs:{display:'flex',borderBottom:'1px solid var(--bd)',flexShrink:0},
  tab:{flex:1,padding:'12px 8px',background:'none',border:'none',color:'var(--mu)',fontSize:12,fontWeight:600,cursor:'pointer',transition:'all 0.15s',borderBottom:'2px solid transparent'},
  tabActive:{color:'var(--acc)',borderBottomColor:'var(--acc)'},
  cardsList:{flex:1,overflowY:'auto',padding:'12px 16px',display:'flex',flexDirection:'column',gap:12},
  card:{background:'var(--s1)',border:'1px solid var(--bd)',borderRadius:16,padding:16,animation:'up 0.4s ease both'},
  cardTop:{display:'flex',gap:12,alignItems:'flex-start',marginBottom:12},
  ava:{width:46,height:46,borderRadius:'50%',objectFit:'cover',border:'2px solid var(--bd)',flexShrink:0},
  avaPh:{width:46,height:46,borderRadius:'50%',background:'linear-gradient(135deg,#e8ff47,#ff6b35)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:18,fontWeight:800,color:'#000',flexShrink:0},
  roleIcon:{position:'absolute',bottom:-4,right:-4,width:18,height:18,borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',fontSize:10,border:'1.5px solid var(--s1)'},
  cardName:{fontWeight:700,fontSize:15},
  roleBadge:{fontSize:10,padding:'2px 8px',borderRadius:999,border:'1px solid',fontWeight:600},
  handle:{fontSize:12,color:'var(--mu)',fontFamily:'DM Mono',marginTop:2},
  starBtn:{background:'none',border:'none',fontSize:22,cursor:'pointer',padding:2,lineHeight:1,flexShrink:0},
  scoreRow:{display:'flex',gap:12,marginBottom:12},
  scoreBlock:{flex:1,display:'flex',flexDirection:'column',gap:5},
  scoreBar:{height:5,background:'var(--bd)',borderRadius:3,overflow:'hidden'},
  scoreFill:{height:'100%',borderRadius:3,transition:'width 0.6s ease'},
  scoreLabels:{display:'flex',justifyContent:'space-between',alignItems:'center'},
  bio:{fontSize:13,color:'#909090',lineHeight:1.55,marginBottom:10,display:'-webkit-box',WebkitLineClamp:2,WebkitBoxOrient:'vertical',overflow:'hidden'},
  matchBox:{background:'rgba(232,255,71,0.05)',borderLeft:'2px solid var(--acc)',borderRadius:'0 8px 8px 0',padding:'8px 12px',fontSize:12,color:'#d0d080',lineHeight:1.55,marginBottom:8},
  flagBox:{background:'rgba(248,113,113,0.06)',borderLeft:'2px solid #f87171',borderRadius:'0 8px 8px 0',padding:'7px 12px',fontSize:11,color:'#f87171',lineHeight:1.5,marginBottom:8},
  tags:{display:'flex',flexWrap:'wrap',gap:6,marginBottom:10},
  tag:{fontFamily:'DM Mono',fontSize:10,color:'var(--mu)',border:'1px solid var(--bd)',padding:'2px 8px',borderRadius:999},
  metrics:{display:'flex',gap:12,marginBottom:12,flexWrap:'wrap'},
  metric:{fontFamily:'DM Mono',fontSize:11,color:'var(--mu)'},
  actionRow:{display:'flex',gap:8,alignItems:'center'},
  followBtn:{flex:1,padding:'9px 12px',borderRadius:10,fontWeight:700,fontSize:12,cursor:'pointer',border:'1px solid',display:'flex',alignItems:'center',justifyContent:'center',gap:6,transition:'all 0.18s'},
  fApprove:{background:'rgba(232,255,71,0.08)',borderColor:'rgba(232,255,71,0.3)',color:'var(--acc)'},
  fConfirm:{background:'rgba(74,222,128,0.08)',borderColor:'rgba(74,222,128,0.35)',color:'var(--green)'},
  fPending:{background:'var(--s2)',borderColor:'var(--bd)',color:'var(--mu)'},
  fDone:{background:'transparent',borderColor:'var(--bd)',color:'var(--mu)',cursor:'default'},
  viewLink:{padding:'9px 12px',borderRadius:10,border:'1px solid var(--bd)',color:'var(--mu)',fontSize:12,fontFamily:'DM Mono',textDecoration:'none',background:'var(--s2)',flexShrink:0},
  backBtn:{background:'var(--s2)',border:'1px solid var(--bd)',color:'var(--tx)',width:36,height:36,borderRadius:10,cursor:'pointer',fontSize:16,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0},
  footer:{textAlign:'center',fontSize:11,color:'var(--mu)',fontFamily:'DM Mono',padding:'14px 0 calc(var(--sb) + 14px)'},
  empty:{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',minHeight:'40vh',color:'var(--mu)',textAlign:'center'},
  spin:{width:14,height:14,border:'2px solid rgba(255,255,255,0.15)',borderTopColor:'#fff',borderRadius:'50%',animation:'spin 0.6s linear infinite',flexShrink:0,display:'inline-block'},
}
