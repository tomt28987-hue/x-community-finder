# Community Finder for X

Find real people with small followings to build a genuine community together.

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_USERNAME/x-community-finder)

## Deploy in 3 steps
1. Push this folder to a GitHub repo
2. Go to vercel.com → Import repo → Deploy
3. Open your URL, paste your Bearer Token, start finding people

## Install as app (PWA)
- **iPhone**: Safari → Share → Add to Home Screen  
- **Android**: Chrome → ⋮ → Install App
- **Desktop**: Chrome address bar install icon

## Features
- Follower range filter (default 1–1,000 to find real people)
- AI community fit + authenticity scores
- Community role labels: The Connector, The Regular, The Contributor, The Quiet One
- Save members across sessions (⭐)
- Two-step manual follow (X automation compliant)
- Works offline as a PWA
